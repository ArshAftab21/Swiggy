import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Food} from './Food';
@Injectable({
  providedIn: 'root'
})
export class FoodServiceService {
path:string;
  constructor(private http: HttpClient) { }

  getFoodItems(): Observable<any> {
  return this.http.get('http://localhost:8080/getFoodItems');
}
 addtoCart(food)
 {
 
   return this.http.post("http://localhost:8080/add",food,{responseType: 'text'});
 }


}
