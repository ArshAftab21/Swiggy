export class User {
    userName: string;
    password: string;
    phone:string
    email:string
    constructor() {
    }
}