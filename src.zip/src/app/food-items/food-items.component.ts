import { Component, OnInit } from '@angular/core';
import { FoodServiceService } from '../food-service.service';
import {Food} from '../Food';

@Component({
  selector: 'app-food-items',
  templateUrl: './food-items.component.html',
  styleUrls: ['./food-items.component.css']
})
export class FoodItemsComponent implements OnInit {
  fooditems: Array<any>;
  food:Food;
  quantity:Number;
  inputNumber:Array<Number>;
  
  constructor(private foodservice: FoodServiceService) {
    this.inputNumber=new Array<Number>();
   }

  ngOnInit() {
    this.foodservice.getFoodItems().subscribe(data => {
      this.fooditems = data;
    });
  }
addtoCart(food)
{
 this.quantity=this.inputNumber[food.id];
 food.quantity=food.quantity-this.quantity;
 this.foodservice.addtoCart(food).subscribe(data=>{
 alert(data);
 });

}


}
