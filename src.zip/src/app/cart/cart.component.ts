import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import {Cart} from '../cart';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
cartitems:Array<any>;
cost:Number;
cart:cart;
price:Number;
inputNumber:Array<Number>;
quantity:Number;
singlePrice:Number;

  constructor(private cartservice: CartService) {
    this.inputNumber=new Array<Number>();
   }

  ngOnInit() {
    this.cartservice.getCartItems().subscribe(data => {
      this.cartitems = data;
    });
    this.cartservice.getTotalCost().subscribe(tcost => {
      this.cost = tcost;
    });
  }

removeFromCart(cart)
{
  this.quantity=this.inputNumber[cart.id];
  this.price=cart.price;
  this.singlePrice=this.price/cart.quantity;
  cart.quantity=cart.quantity-this.quantity;
  cart.price=cart.quantity*this.singlePrice;
 
  console.log(cart);
  this.cartservice.deleteFromCart(cart).subscribe(data=>{
 console.log(data);
   this.ngOnInit();
   console.log(this.cost);
 
 });
 
}




}
