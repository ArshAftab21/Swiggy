package com.swiggy.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.swiggy.model.Cart;
import com.swiggy.model.Food;
import com.swiggy.service.SwiggyService;

@RestController
@CrossOrigin

public class SwiggyController {

	@Autowired
	SwiggyService service;

	@RequestMapping(value = "/")
	public String addItem() {
		//service.addFoodItem();
		return "abcd";
	}

	@GetMapping(value = "getFoodItems", produces = "application/json")
	public List<Food> getFoodList() {
		List<Food> foodList = service.getFoodList();
		return foodList;
	}

	@GetMapping(value = "getCartItems", produces = "application/json")
	public List<Cart> getCartList() {
		List<Cart> cartList = service.getCartList();
		return cartList;
	}

	@PostMapping(value = "add")
	public ResponseEntity<Map<String, String>> addtoCart(@RequestBody Food food) {
		ResponseEntity<Map<String, String>> responseEntity;
		Map<String, String> map1 = new HashMap<>();
		String name = food.getName();

		if (!service.nameExistsInCart(name)) {
			service.addToCart(food);
			map1.put("message", "addedtocart");
		} else {
			service.updateCart(food);
			map1.put("message", "cart Updated");
		}

		responseEntity = new ResponseEntity<Map<String, String>>(map1, HttpStatus.OK);
		return responseEntity;

	}

	@GetMapping(value = "totalCost")
	public int getTotalCost() {
		int price = service.getTotalCost();
		
		return price;
	}

	@PostMapping(value = "delete")
	public ResponseEntity<Map<String, String>> deleteFromCart(@RequestBody Cart cart) {
		ResponseEntity<Map<String, String>> responseEntity;
		Map<String, String> map1 = new HashMap<>();
		service.deleteFromCart(cart);
		map1.put("message", "Removed from Cart");
		responseEntity = new ResponseEntity<Map<String, String>>(map1, HttpStatus.OK);
		return responseEntity;
	}

}
